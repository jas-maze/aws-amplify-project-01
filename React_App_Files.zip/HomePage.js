
import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>Welcome to Our App</h1>
      <p>This is a great place to start your journey with us.</p>
    </div>
  );
};

export default HomePage;
    

import React from 'react';

const UploadsPage = () => {
  return (
    <div>
      <h1>Upload Your Files</h1>
      <input type="file" />
      <button>Upload</button>
    </div>
  );
};

export default UploadsPage;
    
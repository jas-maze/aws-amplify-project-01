
import React from 'react';

const SignUpPage = () => {
  return (
    <div>
      <h1>Sign Up</h1>
      <form>
        <input type="email" placeholder="Email" />
        <input type="password" placeholder="Password" />
        <button type="submit">Sign Up</button>
      </form>
    </div>
  );
};

export default SignUpPage;
    